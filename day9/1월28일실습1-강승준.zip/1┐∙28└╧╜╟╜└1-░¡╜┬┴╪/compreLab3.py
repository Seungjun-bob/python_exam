listv1 = ["A","b","c","D","e","F","G","h"]
listv2 = [i for i in listv1 if i == i.lower()]

print(listv2)