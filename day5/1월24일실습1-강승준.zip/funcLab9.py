def isPYTHON(s):
    if 'PYTHON' in s:
        print("PYTHON이 존재합니다.")
    else:
        print("PYTHON이 존재하지 않습니다.")

isPYTHON("나는 PYTHON을 학습합니다.")
isPYTHON("나는 python을 학습합니다.")
isPYTHON("PYTHON1234")