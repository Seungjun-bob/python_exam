def myprint(*p, deco="**", sep=","):
    k = 1
    answer = []
    for data in p:
        answer.append(data)
    new_answer = [str(a) for a in answer]
    for data in p:
        print(deco, sep.join(new_answer), deco,sep="")


myprint(10,20,30,deco="@",sep="-")
myprint("python","javascript","R",deco="$")
myprint("가","나","다")
myprint(100)
myprint(True,111,False,"abc",deco="&",sep="")


