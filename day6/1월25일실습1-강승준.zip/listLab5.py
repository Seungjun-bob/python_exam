import random

a = random.sample(range(1, 46), 6)
a = str(a)[1:-1]

print("행운의 로또번호 :"+a)
